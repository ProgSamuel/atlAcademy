package com.example.bootcampatlAcademy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootcampAtlAcademyApplicationTests {

	@Test
	void contextLoads() {
	}

}
