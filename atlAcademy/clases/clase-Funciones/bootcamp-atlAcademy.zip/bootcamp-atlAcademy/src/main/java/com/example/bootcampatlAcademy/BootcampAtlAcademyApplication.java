package com.example.bootcampatlAcademy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootcampAtlAcademyApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootcampAtlAcademyApplication.class, args);
	}

}
